package com.supernet.rabbitmqdemo.consumer;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.amqp.rabbit.annotation.RabbitListener;

import com.supernet.rabbitmqdemo.dto.User;

public class RabbitMQJsonConsumer {
	
	private static final Logger LOGGER=LoggerFactory.getLogger(RabbitMQJsonConsumer.class);
	
	@RabbitListener(queues= {"${rabbitmq.json_queue.name}"})
	public void ConsumeJsonMessage(User user) {
		
		LOGGER.info(String.format("Recived Json message ->%s",user.toString()));
		
	}

}


