package com.supernet.rabbitmqdemo.publisher;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

@Service
public class RabbitMQProducer {

	@Value("${rabbitmq.exchange.name}")
	private String exchange;

	@Value("${rabbitmq.routingkey}")
	private String routing_key;

	private RabbitTemplate rabbitTemplete;

	// to print the message
	private static final Logger LOGGER = LoggerFactory.getLogger(RabbitMQProducer.class);

	public RabbitMQProducer(RabbitTemplate rabbitTemplete) {
		this.rabbitTemplete = rabbitTemplete;
	}

	public void sendMessage(String message) {

		LOGGER.info(String.format("Message sent->%s", message));
		rabbitTemplete.convertAndSend(exchange, routing_key, message);
	}

}
