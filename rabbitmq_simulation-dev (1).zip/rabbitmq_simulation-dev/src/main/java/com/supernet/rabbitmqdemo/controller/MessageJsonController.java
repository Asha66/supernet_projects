package com.supernet.rabbitmqdemo.controller;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.supernet.rabbitmqdemo.dto.User;
import com.supernet.rabbitmqdemo.publisher.RabbitMQJsonProducer;

@RestController
@RequestMapping("/Rabbit/jsonMsg")
public class MessageJsonController {
	
	private RabbitMQJsonProducer jsonproducer;

	public MessageJsonController(RabbitMQJsonProducer jsonproducer) {
		this.jsonproducer = jsonproducer;
	}
	//localhost:8080/Rabbit/jsonMsg/publish
	@PostMapping("/publish")
	public ResponseEntity<String> sendJsonMessage(@RequestBody User user){
		jsonproducer.sendJsonMessage(user);
		return ResponseEntity.ok("Json Message sent to RabbitMQ...");
		
	}
}
