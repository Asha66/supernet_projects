package com.supernet.rabbitmqdemo.publisher;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.supernet.rabbitmqdemo.dto.User;

@Service
public class RabbitMQJsonProducer {
	
	@Value("${rabbitmq.exchange.name}")
	private String exchange;
	
	@Value("${rabbitmq.json_routingkey}")
	private String routingJsonKey;
	
	@Value("${rabbitmq.json_routingkey1}")
	private String routingJsonKey1;
	
	private static final Logger LOGGER=LoggerFactory.getLogger(RabbitMQJsonProducer.class);
	
	
	private RabbitTemplate rabbitTemplate;
	
	public RabbitMQJsonProducer(RabbitTemplate rabbitTemplate) {
		this.rabbitTemplate=rabbitTemplate;
	}
	
	public void sendJsonMessage(User user) {
		LOGGER.info(String.format("Json message sent ->%s",user.toString()));
		rabbitTemplate.convertAndSend(exchange, routingJsonKey, user);
		
	}
	
	public void sendJsonMessage1(User user) {
		LOGGER.info(String.format("Json message sent ->%s",user.toString()));
		rabbitTemplate.convertAndSend(exchange, routingJsonKey1, user);
		
	}

}
