package com.Supernet.Controller;

@Controller
@RequestMapping("/employees")
public class EmployeeController {
 
 @Autowired
 private EmployeeRepository employeeRepository;
 
 @Autowired
 private DepartmentRepository departmentRepository;

 @GetMapping
 public String listEmployees(Model model) {
     List<Employee> employees = employeeRepository.findAll();
     model.addAttribute("employees", employees);
     return "employee/list";
 }

 @GetMapping("/create")
 public String createEmployeeForm(Model model) {
     List<Department> departments = departmentRepository.findAll();
     model.addAttribute("employee", new Employee());
     model.addAttribute("departments", departments);
     return "employee/create";
 }

 @PostMapping("/create")
 public String createEmployee(@ModelAttribute Employee employee) {
     employeeRepository.save(employee);
     return "redirect:/employees";
 }

 @GetMapping("/edit/{id}")
 public String editEmployeeForm(@PathVariable Long id, Model model) {
     Employee employee = employeeRepository.findById(id).orElseThrow(() -> new IllegalArgumentException("Invalid employee id: " + id));
     List<Department> departments = departmentRepository.findAll();
     model.addAttribute("employee", employee);
     model.addAttribute("departments", departments);
     return "employee/edit";
 }

 @PostMapping("/edit/{id}")
 public String editEmployee(@PathVariable Long id, @ModelAttribute Employee employee) {
     employee.setId(id);
     employeeRepository.save(employee);
     return "redirect:/employees";
 }

 @GetMapping("/delete/{id}")
 public String deleteEmployee(@PathVariable Long id) {
     employeeRepository.deleteById(id);
     return "redirect:/employees";
 }
}
