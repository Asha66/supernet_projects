package com.Supernet.Model;

import lombok.Getter;

@Entity
@Getter
@Setter
public class Employee {
 @Id
 @GeneratedValue(strategy = GenerationType.IDENTITY)
 private Long id;
 private String firstName;
 private String lastName;
 private String email;

 @ManyToOne
 @JoinColumn(name = "department_id")
 private Department department;


}