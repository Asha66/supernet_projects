package com.supernet.rabbitmqdemo.controller;

import org.springframework.amqp.core.AmqpTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.supernet.rabbitMQdemo.config.Producer;

@RestController
@RequestMapping("/rabbitmq/fanout")
public class Controller {


	@Autowired
	private AmqpTemplate amqpTemplate;

	//localhost:8090/rabbitmq/fanout/producer?exchangeName=fanout-exchange&messageData=msg
	@GetMapping(value = "/producer")
	public String producer(@RequestParam("exchangeName") String exchange,
			@RequestParam("messageData") String messageData) {

		amqpTemplate.convertAndSend(exchange, "", messageData);

		return "Message sent to the RabbitMQ Fanout Exchange Successfully";
	}
}
