package com.supernet.rabbitmqdemo.controller;

import org.springframework.amqp.core.AmqpTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.supernet.rabbitMQdemo.config.Producer;

@RestController
@RequestMapping("/rabbitmq/direct")
public class Controller {

	@Autowired
	private AmqpTemplate amqpTemplate;

	//localhost:8090/rabbitmq/direct/producer?exchangeName=direct-exchange&routingKey=admin&messageData=message
	@GetMapping(value = "/producer")
	public String producer(@RequestParam("exchangeName") String exchange, @RequestParam("routingKey") String routingKey,
			@RequestParam("messageData") String messageData) {

		amqpTemplate.convertAndSend(exchange, routingKey, messageData);

		return "Message sent to the RabbitMQ Successfully";
	}
}
